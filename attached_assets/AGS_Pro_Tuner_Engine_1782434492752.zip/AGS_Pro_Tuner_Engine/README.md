# AGS Pro Tuner Engine

This is the upgraded tuner engine for Fretboard Universe.

It is designed to compete with serious phone tuners by using:

- McLeod Pitch Method style pitch detection
- 8192 sample buffer for Android stability and low strings
- RMS noise gate
- DC removal
- Hann windowing
- NSDF pitch detection
- Parabolic peak refinement
- Rolling weighted median smoothing
- Octave error correction
- Auto string mode
- Lock string mode
- ±3 cents in tune
- ±1 cent perfect

## Files

- src/tuner/PitchDetectorMPM.ts
- src/tuner/PitchSmoother.ts
- src/tuner/TunerEngine.ts
- src/tuner/tuningLibrary.ts
- src/tuner/useProTuner.ts

## Usage

Import `useProTuner` into your tuner screen.

```ts
const tuner = useProTuner({
  instrument: "guitar",
  stringCount: 6,
  tuning: "standard",
  a4: 440,
});
```

Then use:

```ts
tuner.start()
tuner.stop()
tuner.lockString(0)
tuner.autoMode()
tuner.reading?.cents
```

## Important

No one can honestly guarantee “more accurate than GuitarTuna” without device testing, because microphone hardware, Android audio processing, room noise, and sample rate all matter.

This engine gives your developer the right architecture to get extremely close or better after QA tuning.

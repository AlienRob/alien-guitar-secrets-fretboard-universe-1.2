import { Instrument, StringTarget } from "./types";

export function midiToFrequency(midi: number, a4 = 440): number {
  return a4 * Math.pow(2, (midi - 69) / 12);
}
function t(id: string, label: string, midi: number, a4: number): StringTarget {
  return { id, label, midi, frequency: midiToFrequency(midi, a4) };
}
export function getTargets(instrument: Instrument, stringCount: number, tuning: string, a4 = 440): StringTarget[] {
  const shift = tuning === "semitoneDown" ? -1 : tuning === "wholeToneDown" ? -2 : 0;
  const g6 = [["lowE","E2",40],["A","A2",45],["D","D3",50],["G","G3",55],["B","B3",59],["highE","E4",64]] as const;
  const b4 = [["E","E1",28],["A","A1",33],["D","D2",38],["G","G2",43]] as const;
  const u4 = [["G","G4",67],["C","C4",60],["E","E4",64],["A","A4",69]] as const;

  if (instrument === "guitar") {
    if (stringCount === 6 && tuning === "dropD") return [t("lowD","D2",38,a4),t("A","A2",45,a4),t("D","D3",50,a4),t("G","G3",55,a4),t("B","B3",59,a4),t("highE","E4",64,a4)];
    if (stringCount === 6 || stringCount === 12) return g6.map(([id,l,m]) => t(id,l,m+shift,a4));
    if (stringCount === 7) return [t("lowB","B1",35+shift,a4), ...g6.map(([id,l,m]) => t(id,l,m+shift,a4))];
    if (stringCount === 8) return [t("lowF#","F#1",30+shift,a4), t("lowB","B1",35+shift,a4), ...g6.map(([id,l,m]) => t(id,l,m+shift,a4))];
  }
  if (instrument === "bass") {
    if (stringCount === 4) return b4.map(([id,l,m]) => t(id,l,m+shift,a4));
    if (stringCount === 5) return [t("B","B0",23+shift,a4), ...b4.map(([id,l,m]) => t(id,l,m+shift,a4))];
    if (stringCount === 6) return [t("B","B0",23+shift,a4), ...b4.map(([id,l,m]) => t(id,l,m+shift,a4)), t("C","C3",48+shift,a4)];
  }
  if (instrument === "uke") {
    if (stringCount === 4) return u4.map(([id,l,m]) => t(id,l,m+shift,a4));
    if (stringCount === 6) return [t("G","G4",67+shift,a4),t("C","C4",60+shift,a4),t("C5","C5",72+shift,a4),t("E","E4",64+shift,a4),t("A3","A3",57+shift,a4),t("A","A4",69+shift,a4)];
  }
  return g6.map(([id,l,m]) => t(id,l,m,a4));
}

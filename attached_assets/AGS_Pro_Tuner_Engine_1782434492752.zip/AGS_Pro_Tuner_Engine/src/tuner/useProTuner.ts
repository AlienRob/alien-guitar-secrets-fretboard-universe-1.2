import { useEffect, useRef, useState } from "react";
import { TunerEngine } from "./TunerEngine";
import { Instrument, TunerReading } from "./types";

export function useProTuner(options: { instrument: Instrument; stringCount: number; tuning: string; a4: number }) {
  const [reading, setReading] = useState<TunerReading | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const engineRef = useRef(new TunerEngine(options));
  const contextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const bufferRef = useRef<Float32Array | null>(null);
  const rafRef = useRef<number | null>(null);

  useEffect(() => { engineRef.current.setTargets(options); }, [options.instrument, options.stringCount, options.tuning, options.a4]);

  async function start() {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false },
      });
      const context = new AudioContext({ latencyHint: "interactive" });
      const source = context.createMediaStreamSource(stream);
      const analyser = context.createAnalyser();
      analyser.fftSize = 8192; // Android + bass stability.
      analyser.smoothingTimeConstant = 0;
      source.connect(analyser);
      streamRef.current = stream; contextRef.current = context; analyserRef.current = analyser;
      bufferRef.current = new Float32Array(analyser.fftSize);
      setRunning(true); loop();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Microphone permission failed");
    }
  }

  function stop() {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach(t => t.stop());
    contextRef.current?.close();
    streamRef.current = null; contextRef.current = null; analyserRef.current = null; bufferRef.current = null;
    setRunning(false); setReading(null);
  }

  function loop() {
    const analyser = analyserRef.current, buffer = bufferRef.current, context = contextRef.current;
    if (!analyser || !buffer || !context) return;
    analyser.getFloatTimeDomainData(buffer);
    const result = engineRef.current.process(buffer, context.sampleRate);
    if (result) setReading(result);
    rafRef.current = requestAnimationFrame(loop);
  }

  useEffect(() => () => stop(), []);

  return {
    reading, running, error, start, stop,
    lockString: (index: number) => engineRef.current.lockString(index),
    autoMode: () => engineRef.current.autoMode(),
  };
}

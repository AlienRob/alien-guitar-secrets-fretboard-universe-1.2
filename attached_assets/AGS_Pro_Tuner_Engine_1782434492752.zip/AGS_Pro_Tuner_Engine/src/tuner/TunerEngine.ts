import { PitchDetectorMPM } from "./PitchDetectorMPM";
import { PitchSmoother } from "./PitchSmoother";
import { Instrument, StringTarget, TunerMode, TunerReading } from "./types";
import { getTargets } from "./tuningLibrary";

export class TunerEngine {
  private detector: PitchDetectorMPM;
  private smoother = new PitchSmoother(9, 20);
  private targets: StringTarget[];
  private lockedTargetIndex = 0;
  public mode: TunerMode = "auto";
  public inTuneCents = 3;
  public perfectCents = 1;

  constructor(options: { instrument: Instrument; stringCount: number; tuning: string; a4: number }) {
    this.targets = getTargets(options.instrument, options.stringCount, options.tuning, options.a4);
    this.detector = this.makeDetector(options.instrument);
  }

  setTargets(options: { instrument: Instrument; stringCount: number; tuning: string; a4: number }) {
    this.targets = getTargets(options.instrument, options.stringCount, options.tuning, options.a4);
    this.lockedTargetIndex = Math.min(this.lockedTargetIndex, this.targets.length - 1);
    this.smoother.reset();
    this.detector = this.makeDetector(options.instrument);
  }

  lockString(index: number) { this.lockedTargetIndex = Math.max(0, Math.min(index, this.targets.length - 1)); this.mode = "locked"; this.smoother.reset(); }
  autoMode() { this.mode = "auto"; this.smoother.reset(); }

  process(buffer: Float32Array, sampleRate: number): TunerReading | null {
    const raw = this.detector.detect(buffer, sampleRate);
    if (!raw) return null;
    const smoothed = this.smoother.push(raw);
    const target = this.mode === "locked" ? this.targets[this.lockedTargetIndex] : this.pickBestTarget(smoothed.frequency);
    const corrected = this.rejectOctaveError(smoothed.frequency, target.frequency);
    const cents = 1200 * Math.log2(corrected / target.frequency);
    const abs = Math.abs(cents);
    return {
      note: target.label, target, frequency: corrected, targetFrequency: target.frequency, cents,
      inTune: abs <= this.inTuneCents, perfect: abs <= this.perfectCents,
      confidence: Math.min(1, smoothed.clarity * smoothed.probability), stable: this.smoother.stable,
    };
  }

  private pickBestTarget(freq: number): StringTarget {
    let best = this.targets[0], bestScore = Infinity;
    for (const target of this.targets) {
      const candidates = [freq, freq / 2, freq * 2];
      const score = Math.min(...candidates.map(f => Math.abs(1200 * Math.log2(f / target.frequency))));
      if (score < bestScore) { bestScore = score; best = target; }
    }
    return best;
  }

  private rejectOctaveError(freq: number, targetFreq: number): number {
    const candidates = [freq, freq / 2, freq * 2, freq / 3, freq * 3].filter(f => f > 20 && f < 2000);
    return candidates.reduce((best, f) =>
      Math.abs(1200 * Math.log2(f / targetFreq)) < Math.abs(1200 * Math.log2(best / targetFreq)) ? f : best
    , candidates[0]);
  }

  private makeDetector(instrument: Instrument) {
    return new PitchDetectorMPM({
      minFrequency: instrument === "bass" ? 25 : instrument === "uke" ? 150 : 55,
      maxFrequency: instrument === "bass" ? 520 : instrument === "uke" ? 1200 : 1100,
      noiseGateRms: instrument === "bass" ? 0.008 : 0.01,
      clarityThreshold: instrument === "bass" ? 0.82 : 0.86,
    });
  }
}

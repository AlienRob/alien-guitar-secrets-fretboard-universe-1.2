# AGS Fretboard Universe — Mobile Tuner Developer Brief

## Purpose
Build a premium mobile tuner screen for Fretboard Universe using the supplied React/TypeScript prototype and labelled PNG/SVG assets.

The tuner must feel like part of the Alien Guitar Secrets universe: dark cosmic background, purple/gold palette, official AGS branding, vertical fretboard, active string vibration, and a premium tuner display.

## Brand Rules
Use only the supplied official AGS assets:

- `src/assets/branding/AGS_COA.svg`
- `src/assets/branding/AGS_Wordmark.svg`

Do not use the removed `Horizontal Web Banner_.svg`.
Do not invent new AGS logos, alien marks, fonts, or brand symbols.

## Mobile Requirements
The layout is mobile-first and uses:

- `100dvh`
- `viewport-fit=cover`
- `env(safe-area-inset-top)`
- `env(safe-area-inset-bottom)`
- `clamp()` sizing
- responsive breakpoints for older/smaller phones

Target devices:

- iPhone SE and newer
- iPhone standard / Pro / Pro Max
- Samsung Galaxy S series
- older Android phones
- large Android devices
- tablets as a centred mobile-width layout

## Functionality Included
- Microphone input using Web Audio API
- Pitch detection via autocorrelation
- A4 calibration from 430Hz to 450Hz
- Auto string detection
- String lock mode
- Active string vibration animation
- Detected Hz readout
- Flat / sharp / perfect tune status
- Tuner scale with animated glowing needle

## Instruments & Tunings
Included:

### Guitar
- 6 string
- 7 string
- 8 string
- 12 string

Tunings:
- Standard
- Semitone down
- Whole tone down
- Drop D
- DADGAD
- Open G
- Drop A
- Drop E

### Bass
- 4 string
- 5 string
- 6 string

Tunings:
- Standard
- Semitone down
- Whole tone down
- Drop D

### Ukulele
- 4 string
- 6 string

Tunings:
- Standard
- Low G
- Semitone down

## Asset Strategy
Use PNG for painterly/photoreal texture assets:

- `space_background.png`
- `fretboard_wood.png`
- `fretboard_cosmic_glow_overlay.png`
- `active_string_vibration_wave.png`
- `dropdown_bar.png`
- `bottom_panel.png`

Use SVG for precision/scalable assets:

- frets
- strings
- nut
- tuner scale
- icons
- note buttons
- AGS brand assets

## Key Files
- `src/FretboardUniverseTuner.tsx` — main UI component
- `src/tunerData.ts` — instruments and tunings
- `src/pitch.ts` — pitch detection and tuning math
- `src/styles.css` — responsive mobile layout and animation
- `src/assets/` — all labelled assets

## Run Locally
```bash
npm install
npm run dev
```

Allow microphone access in the browser.

## Production Notes
This is a strong developer-ready prototype, not final native production code.

For a final App Store / Google Play build, either:

1. Wrap this in Capacitor/Ionic for a web-based mobile app, or
2. Port the UI to React Native / Expo and reuse:
   - `tunerData.ts`
   - tuning math from `pitch.ts`
   - the supplied SVG/PNG asset structure

For React Native, replace Web Audio API pitch detection with a native audio input/pitch detection module.

## Accuracy Notes
The fret overlay uses equal-temperament fret spacing for 24 frets.
Pitch detection is good for a prototype, but production should be tested against:
- GuitarTuna
- Peterson
- Boss tuner
- real guitars/bass/uke
- quiet room and noisy room
- multiple phones

## Recommended Next Developer Tasks
1. Test microphone permission handling on iOS Safari and Android Chrome.
2. Improve pitch detection smoothing and octave rejection.
3. Add noise gate and confidence value.
4. Add chromatic mode.
5. Add haptic feedback when in tune.
6. Save last selected instrument/tuning/calibration to local storage.
7. Add onboarding screen: “Allow microphone access”.
8. Replace browser select styling if building native.
9. Add portrait-only lock for the tuner screen.
10. QA on iPhone SE-size screens.

## File Naming
Do not rename the AGS branding files unless updating imports:

- `AGS_COA.svg`
- `AGS_Wordmark.svg`

The horizontal web banner has intentionally been excluded.

import React from "react";
import { createRoot } from "react-dom/client";
import FretboardUniverseTuner from "./FretboardUniverseTuner";
import "./styles.css";

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <FretboardUniverseTuner />
  </React.StrictMode>
);

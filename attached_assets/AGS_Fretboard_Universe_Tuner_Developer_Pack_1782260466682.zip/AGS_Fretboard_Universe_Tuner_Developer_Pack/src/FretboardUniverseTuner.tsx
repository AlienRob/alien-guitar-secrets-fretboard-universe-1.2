import { useEffect, useMemo, useRef, useState } from "react";
import { Instrument, tunings } from "./tunerData";
import { autoCorrelate, getCentsOff, midiToFrequency } from "./pitch";

type LockMode = "auto" | "locked";
const A = "/src/assets/";

export default function FretboardUniverseTuner() {
  const [instrument, setInstrument] = useState<Instrument>("guitar");
  const [stringCount, setStringCount] = useState("6");
  const [tuningIndex, setTuningIndex] = useState(0);
  const [a4, setA4] = useState(440);
  const [lockMode, setLockMode] = useState<LockMode>("auto");
  const [lockedString, setLockedString] = useState(0);
  const [activeString, setActiveString] = useState<number | null>(null);
  const [detectedFreq, setDetectedFreq] = useState<number | null>(null);
  const [targetFreq, setTargetFreq] = useState<number | null>(null);
  const [cents, setCents] = useState(0);
  const [running, setRunning] = useState(false);
  const [vibration, setVibration] = useState(0);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const bufferRef = useRef<Float32Array | null>(null);
  const rafRef = useRef<number | null>(null);

  const counts = Object.keys(tunings[instrument]);
  const tuning = useMemo(() => tunings[instrument][stringCount][tuningIndex], [instrument, stringCount, tuningIndex]);

  useEffect(() => {
    const first = Object.keys(tunings[instrument])[0];
    setStringCount(first);
    setTuningIndex(0);
    setLockedString(0);
  }, [instrument]);

  useEffect(() => {
    setTuningIndex(0);
    setLockedString(0);
  }, [stringCount]);

  useEffect(() => () => stop(), []);

  async function start() {
    if (running) return;
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false }
    });
    const audioContext = new AudioContext();
    const source = audioContext.createMediaStreamSource(stream);
    const analyser = audioContext.createAnalyser();
    analyser.fftSize = 4096;
    analyser.smoothingTimeConstant = 0;
    source.connect(analyser);

    mediaStreamRef.current = stream;
    audioContextRef.current = audioContext;
    analyserRef.current = analyser;
    bufferRef.current = new Float32Array(analyser.fftSize);
    setRunning(true);
    tick(audioContext.sampleRate);
  }

  function stop() {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    mediaStreamRef.current?.getTracks().forEach((track) => track.stop());
    audioContextRef.current?.close();
    mediaStreamRef.current = null;
    audioContextRef.current = null;
    analyserRef.current = null;
    bufferRef.current = null;
    setRunning(false);
    setDetectedFreq(null);
    setTargetFreq(null);
    setActiveString(null);
    setVibration(0);
  }

  function tick(sampleRate: number) {
    const analyser = analyserRef.current;
    const buffer = bufferRef.current;
    if (!analyser || !buffer) return;

    analyser.getFloatTimeDomainData(buffer);
    const freq = autoCorrelate(buffer, sampleRate);

    if (freq > 0 && freq < 2000) {
      const targetIndex = lockMode === "locked" ? lockedString : closestString(freq);
      const target = midiToFrequency(tuning.strings[targetIndex].midi, a4);
      const centsOff = getCentsOff(freq, target);

      setDetectedFreq(freq);
      setTargetFreq(target);
      setActiveString(targetIndex);
      setCents(Math.max(-50, Math.min(50, centsOff)));
      setVibration(Math.max(0.12, Math.min(1, 1 - Math.abs(centsOff) / 50)));
    } else {
      setVibration((v) => Math.max(0, v - 0.05));
    }

    rafRef.current = requestAnimationFrame(() => tick(sampleRate));
  }

  function closestString(freq: number) {
    let best = 0;
    let bestDiff = Infinity;
    tuning.strings.forEach((s, i) => {
      const target = midiToFrequency(s.midi, a4);
      const diff = Math.abs(getCentsOff(freq, target));
      if (diff < bestDiff) {
        best = i;
        bestDiff = diff;
      }
    });
    return best;
  }

  const inTune = detectedFreq != null && Math.abs(cents) <= 4;
  const activeNote = activeString == null ? "—" : tuning.strings[activeString].label;
  const needleLeft = `${50 + cents}%`;
  const lockedNote = tuning.strings[lockedString]?.label ?? tuning.strings[0].label;

  return (
    <main className="screen">
      <img className="space-bg" src={A + "png/space_background.png"} alt="" />

      <header className="header">
        <button className="icon-btn"><img src={A + "svg/hamburger_icon.svg"} alt="" /></button>
        <div className="logo-row">
          <img src={A + "branding/AGS_COA.svg"} alt="AGS" />
          <img className="wordmark" src={A + "branding/AGS_Wordmark.svg"} alt="Alien Guitar Secrets" />
        </div>
        <button className="icon-btn"><img src={A + "svg/settings_icon.svg"} alt="" /></button>
      </header>

      <section className="instrument-select">
        <img src={A + "png/dropdown_bar.png"} alt="" />
        <img className="inst-icon" src={A + "svg/instrument_guitar_icon.svg"} alt="" />
        <select value={instrument} onChange={(e) => setInstrument(e.target.value as Instrument)}>
          <option value="guitar">Electric Guitar</option>
          <option value="bass">Bass</option>
          <option value="uke">Ukulele</option>
        </select>
        <select value={stringCount} onChange={(e) => setStringCount(e.target.value)}>
          {counts.map((c) => <option key={c} value={c}>{c} String</option>)}
        </select>
      </section>

      <section className="readout">
        <div className="note">{activeNote}</div>
        <div className="detected">{detectedFreq ? detectedFreq.toFixed(2) : "--"} Hz</div>
        <div className={`tune-state ${inTune ? "good" : ""}`}>
          {detectedFreq == null ? "PLAY A STRING" : inTune ? "PERFECT TUNE" : cents < 0 ? "FLAT" : "SHARP"}
        </div>
      </section>

      <section className="meter">
        <img className="ticks" src={A + "svg/tuner_scale_ticks.svg"} alt="" />
        <img className="needle" src={A + "svg/needle_glow.svg"} alt="" style={{ left: needleLeft }} />
        <span className="flat">FLAT</span>
        <span className="sharp">SHARP</span>
        <span className="zero">0</span>
      </section>

      <section className="fretboard">
        <img className="wood" src={A + "png/fretboard_wood.png"} alt="" />
        <img className="frets" src={A + "svg/fretwire_24_equal_temperament.svg"} alt="" />
        <img className="nut" src={A + "svg/nut_gold_cream.svg"} alt="" />
        <img className="glow" src={A + "png/fretboard_cosmic_glow_overlay.png"} alt="" />

        <div className="string-grid" style={{ gridTemplateColumns: `repeat(${tuning.strings.length}, 1fr)` }}>
          {tuning.strings.map((s, i) => {
            const active = i === activeString;
            return (
              <button
                key={`${s.label}-${i}`}
                className={`string-slot ${active ? "active" : ""} ${i === lockedString ? "locked" : ""}`}
                onClick={() => { setLockedString(i); setLockMode("locked"); }}
              >
                {active && <img className="wave" src={A + "png/active_string_vibration_wave.png"} alt="" />}
                <img
                  className="string-img"
                  src={A + "svg/" + (s.asset ?? "string_high_E_plain.svg")}
                  alt=""
                  style={{ ["--vibe" as any]: active ? `${vibration * 8}px` : "0px" }}
                />
                <span className="note-btn">
                  <img src={A + `svg/${active ? "note_button_active.svg" : "note_button_inactive.svg"}`} alt="" />
                  <b>{s.label}</b>
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="tuning-select">
        <img src={A + "png/dropdown_bar.png"} alt="" />
        <select value={tuningIndex} onChange={(e) => setTuningIndex(Number(e.target.value))}>
          {tunings[instrument][stringCount].map((t, i) => <option key={t.label} value={i}>{t.label}</option>)}
        </select>
      </section>

      <section className="bottom">
        <img className="panel" src={A + "png/bottom_panel.png"} alt="" />
        <button className="lock" onClick={() => setLockMode(lockMode === "auto" ? "locked" : "auto")}>
          {lockMode === "auto" ? "AUTO" : `LOCK ${lockedNote}`}
        </button>
        <div className={`core ${inTune ? "balanced" : ""}`}>
          <img className="core-bg" src={A + "svg/galactic_core.svg"} alt="" />
          <img className="core-logo" src={A + "branding/AGS_COA.svg"} alt="" />
        </div>
        <label className="calibration">A4 {a4}Hz
          <input type="range" min="430" max="450" value={a4} onChange={(e) => setA4(Number(e.target.value))}/>
        </label>
      </section>

      <button className="start" onClick={running ? stop : start}>{running ? "STOP TUNER" : "START TUNER"}</button>
    </main>
  );
}

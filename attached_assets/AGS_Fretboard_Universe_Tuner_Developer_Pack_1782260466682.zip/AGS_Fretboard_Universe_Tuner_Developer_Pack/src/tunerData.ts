export type Instrument = "guitar" | "bass" | "uke";
export type StringNote = { label: string; midi: number; asset?: string; };
export type TuningPreset = { label: string; strings: StringNote[]; };

const stringAssets = [
  "string_low_E_heavy_wound.svg",
  "string_A_wound.svg",
  "string_D_wound.svg",
  "string_G_plain.svg",
  "string_B_plain.svg",
  "string_high_E_plain.svg",
];

const withAssets = (strings: Omit<StringNote, "asset">[]): StringNote[] =>
  strings.map((s, i) => ({ ...s, asset: stringAssets[Math.min(i, stringAssets.length - 1)] }));

const shift = (strings: StringNote[], semitones: number): StringNote[] =>
  strings.map((s) => ({ ...s, midi: s.midi + semitones }));

const guitar6 = withAssets([
  { label: "E", midi: 40 }, { label: "A", midi: 45 }, { label: "D", midi: 50 },
  { label: "G", midi: 55 }, { label: "B", midi: 59 }, { label: "E", midi: 64 },
]);

const bass4 = withAssets([
  { label: "E", midi: 28 }, { label: "A", midi: 33 }, { label: "D", midi: 38 }, { label: "G", midi: 43 },
]);

const uke4 = withAssets([
  { label: "G", midi: 67 }, { label: "C", midi: 60 }, { label: "E", midi: 64 }, { label: "A", midi: 69 },
]);

export const tunings: Record<Instrument, Record<string, TuningPreset[]>> = {
  guitar: {
    "6": [
      { label: "Standard Tuning", strings: guitar6 },
      { label: "Semitone Down", strings: shift(guitar6, -1) },
      { label: "Whole Tone Down", strings: shift(guitar6, -2) },
      { label: "Drop D", strings: withAssets([{ label: "D", midi: 38 }, { label: "A", midi: 45 }, { label: "D", midi: 50 }, { label: "G", midi: 55 }, { label: "B", midi: 59 }, { label: "E", midi: 64 }]) },
      { label: "DADGAD", strings: withAssets([{ label: "D", midi: 38 }, { label: "A", midi: 45 }, { label: "D", midi: 50 }, { label: "G", midi: 55 }, { label: "A", midi: 57 }, { label: "D", midi: 62 }]) },
      { label: "Open G", strings: withAssets([{ label: "D", midi: 38 }, { label: "G", midi: 43 }, { label: "D", midi: 50 }, { label: "G", midi: 55 }, { label: "B", midi: 59 }, { label: "D", midi: 62 }]) },
    ],
    "7": [
      { label: "Standard Tuning", strings: withAssets([{ label: "B", midi: 35 }, { label: "E", midi: 40 }, { label: "A", midi: 45 }, { label: "D", midi: 50 }, { label: "G", midi: 55 }, { label: "B", midi: 59 }, { label: "E", midi: 64 }]) },
      { label: "Drop A", strings: withAssets([{ label: "A", midi: 33 }, { label: "E", midi: 40 }, { label: "A", midi: 45 }, { label: "D", midi: 50 }, { label: "G", midi: 55 }, { label: "B", midi: 59 }, { label: "E", midi: 64 }]) },
    ],
    "8": [
      { label: "Standard Tuning", strings: withAssets([{ label: "F#", midi: 30 }, { label: "B", midi: 35 }, { label: "E", midi: 40 }, { label: "A", midi: 45 }, { label: "D", midi: 50 }, { label: "G", midi: 55 }, { label: "B", midi: 59 }, { label: "E", midi: 64 }]) },
      { label: "Drop E", strings: withAssets([{ label: "E", midi: 28 }, { label: "B", midi: 35 }, { label: "E", midi: 40 }, { label: "A", midi: 45 }, { label: "D", midi: 50 }, { label: "G", midi: 55 }, { label: "B", midi: 59 }, { label: "E", midi: 64 }]) },
    ],
    "12": [
      { label: "Standard Tuning", strings: guitar6 },
      { label: "Semitone Down", strings: shift(guitar6, -1) },
    ],
  },
  bass: {
    "4": [
      { label: "Standard Tuning", strings: bass4 },
      { label: "Semitone Down", strings: shift(bass4, -1) },
      { label: "Whole Tone Down", strings: shift(bass4, -2) },
      { label: "Drop D", strings: withAssets([{ label: "D", midi: 26 }, { label: "A", midi: 33 }, { label: "D", midi: 38 }, { label: "G", midi: 43 }]) },
    ],
    "5": [
      { label: "Standard Tuning", strings: withAssets([{ label: "B", midi: 23 }, { label: "E", midi: 28 }, { label: "A", midi: 33 }, { label: "D", midi: 38 }, { label: "G", midi: 43 }]) },
      { label: "Semitone Down", strings: shift(withAssets([{ label: "B", midi: 23 }, { label: "E", midi: 28 }, { label: "A", midi: 33 }, { label: "D", midi: 38 }, { label: "G", midi: 43 }]), -1) },
    ],
    "6": [
      { label: "Standard Tuning", strings: withAssets([{ label: "B", midi: 23 }, { label: "E", midi: 28 }, { label: "A", midi: 33 }, { label: "D", midi: 38 }, { label: "G", midi: 43 }, { label: "C", midi: 48 }]) },
    ],
  },
  uke: {
    "4": [
      { label: "Standard Tuning", strings: uke4 },
      { label: "Low G", strings: withAssets([{ label: "G", midi: 55 }, { label: "C", midi: 60 }, { label: "E", midi: 64 }, { label: "A", midi: 69 }]) },
      { label: "Semitone Down", strings: shift(uke4, -1) },
    ],
    "6": [
      { label: "Standard Tuning", strings: withAssets([{ label: "G", midi: 67 }, { label: "C", midi: 60 }, { label: "C", midi: 72 }, { label: "E", midi: 64 }, { label: "A", midi: 57 }, { label: "A", midi: 69 }]) },
    ],
  },
};

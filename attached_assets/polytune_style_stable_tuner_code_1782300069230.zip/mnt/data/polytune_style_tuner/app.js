const startBtn = document.getElementById('startBtn');
const needle = document.getElementById('needle');
const noteName = document.getElementById('noteName');
const cents = document.getElementById('cents');
const frequency = document.getElementById('frequency');
const statusText = document.getElementById('status');
const strings = [...document.querySelectorAll('.string')];

let audioContext;
let analyser;
let source;
let tuner;
let buffer;

startBtn.addEventListener('click', async () => {
  try {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false
      }
    });

    source = audioContext.createMediaStreamSource(stream);
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 4096;
    analyser.smoothingTimeConstant = 0;
    source.connect(analyser);

    buffer = new Float32Array(analyser.fftSize);
    tuner = new StableGuitarTuner({
      minFrequency: 60,
      maxFrequency: 1400,
      attackRejectMs: 90,
      analysisWindowMs: 260,
      minRms: 0.008,
      minClarity: 0.72,
      centerLockCents: 2,
      displaySmoothing: 0.22
    });

    startBtn.textContent = 'Tuner Running';
    startBtn.disabled = true;
    tick();
  } catch (err) {
    statusText.textContent = 'Microphone permission was blocked or unavailable.';
    console.error(err);
  }
});

function tick() {
  analyser.getFloatTimeDomainData(buffer);
  const result = tuner.process(buffer, audioContext.sampleRate);
  updateUi(result);
  requestAnimationFrame(tick);
}

function updateUi(result) {
  strings.forEach(s => s.classList.remove('active'));

  if (!result.active) {
    statusText.textContent = 'Play a string…';
    needle.style.transform = `translateX(-50%) rotate(0deg)`;
    return;
  }

  if (result.settling) {
    statusText.textContent = 'Settling after pick attack…';
    activateLoudestVisualOnly();
    return;
  }

  if (!result.stable) {
    statusText.textContent = `Listening… confidence ${(result.confidence * 100).toFixed(0)}%`;
    activateLoudestVisualOnly();
    return;
  }

  const shownCents = Math.max(-50, Math.min(50, result.displayCents));
  const angle = shownCents * 0.9;
  needle.style.transform = `translateX(-50%) rotate(${angle}deg)`;

  const pureCents = result.cents;
  noteName.textContent = `${result.noteName}${result.octave}`;
  cents.textContent = `${pureCents > 0 ? '+' : ''}${pureCents} cents`;
  frequency.textContent = `${result.frequency.toFixed(2)} Hz`;

  noteName.className = 'note';
  if (Math.abs(pureCents) <= 2) {
    statusText.textContent = 'IN TUNE';
    noteName.classList.add('in-tune');
    needle.style.background = '#59ffb4';
  } else if (pureCents < 0) {
    statusText.textContent = 'FLAT — tune up';
    noteName.classList.add('flat');
    needle.style.background = '#ffd86a';
  } else {
    statusText.textContent = 'SHARP — tune down';
    noteName.classList.add('sharp');
    needle.style.background = '#ffd86a';
  }

  const stringId = tuner.closestStandardString(result.noteName, result.octave);
  if (stringId) document.querySelector(`[data-note="${stringId}"]`)?.classList.add('active');
}

function activateLoudestVisualOnly() {
  // During attack/uncertain moments we still show vibration feedback.
  // In production this can be replaced with string-range energy detection.
  strings.forEach(s => s.classList.remove('active'));
}

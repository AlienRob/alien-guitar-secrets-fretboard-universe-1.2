class StableGuitarTuner {
  constructor(options = {}) {
    this.sampleRate = options.sampleRate || 44100;
    this.minFrequency = options.minFrequency || 60;
    this.maxFrequency = options.maxFrequency || 1400;
    this.attackRejectMs = options.attackRejectMs || 90;
    this.analysisWindowMs = options.analysisWindowMs || 260;
    this.minRms = options.minRms || 0.008;
    this.minClarity = options.minClarity || 0.72;
    this.centerLockCents = options.centerLockCents || 2;
    this.displaySmoothing = options.displaySmoothing || 0.22;
    this.history = [];
    this.attackStart = 0;
    this.wasLoud = false;
    this.smoothedCents = 0;
    this.lastStable = null;
  }

  process(buffer, sampleRate, nowMs = performance.now()) {
    this.sampleRate = sampleRate;
    const rms = this.getRms(buffer);
    const isLoud = rms > this.minRms;

    if (isLoud && !this.wasLoud) this.attackStart = nowMs;
    this.wasLoud = isLoud;

    if (!isLoud) {
      this.history = [];
      return { active: false, confidence: 0, rms };
    }

    const msSinceAttack = nowMs - this.attackStart;
    if (msSinceAttack < this.attackRejectMs) {
      return { active: true, settling: true, confidence: 0, rms };
    }

    const pitch = this.detectPitchAutocorrelation(buffer, sampleRate);
    if (!pitch || pitch.clarity < this.minClarity) {
      return { active: true, confidence: pitch?.clarity || 0, rms };
    }

    const note = this.frequencyToNote(pitch.frequency);
    const reading = {
      frequency: pitch.frequency,
      clarity: pitch.clarity,
      note,
      time: nowMs
    };

    this.history.push(reading);
    this.history = this.history.filter(r => nowMs - r.time <= this.analysisWindowMs);

    const stable = this.getStableReading();
    if (!stable) return { active: true, confidence: pitch.clarity, rms };

    const centsTarget = Math.abs(stable.note.cents) <= this.centerLockCents ? 0 : stable.note.cents;
    this.smoothedCents += (centsTarget - this.smoothedCents) * this.displaySmoothing;

    this.lastStable = {
      active: true,
      stable: true,
      frequency: stable.frequency,
      noteName: stable.note.name,
      octave: stable.note.octave,
      cents: stable.note.cents,
      displayCents: this.smoothedCents,
      confidence: stable.confidence,
      rms
    };

    return this.lastStable;
  }

  getRms(buffer) {
    let sum = 0;
    for (let i = 0; i < buffer.length; i++) sum += buffer[i] * buffer[i];
    return Math.sqrt(sum / buffer.length);
  }

  detectPitchAutocorrelation(buffer, sampleRate) {
    const size = buffer.length;
    const minLag = Math.floor(sampleRate / this.maxFrequency);
    const maxLag = Math.floor(sampleRate / this.minFrequency);
    let bestLag = -1;
    let bestCorrelation = 0;

    for (let lag = minLag; lag <= maxLag; lag++) {
      let correlation = 0;
      let energy1 = 0;
      let energy2 = 0;

      for (let i = 0; i < size - lag; i++) {
        const a = buffer[i];
        const b = buffer[i + lag];
        correlation += a * b;
        energy1 += a * a;
        energy2 += b * b;
      }

      const normalized = correlation / Math.sqrt(energy1 * energy2 || 1);
      if (normalized > bestCorrelation) {
        bestCorrelation = normalized;
        bestLag = lag;
      }
    }

    if (bestLag < 0) return null;

    const refinedLag = this.parabolicRefine(buffer, bestLag, sampleRate);
    const frequency = sampleRate / refinedLag;

    return { frequency, clarity: bestCorrelation };
  }

  parabolicRefine(buffer, lag, sampleRate) {
    const corrAt = (l) => {
      let c = 0;
      for (let i = 0; i < buffer.length - l; i++) c += buffer[i] * buffer[i + l];
      return c;
    };

    const y1 = corrAt(Math.max(1, lag - 1));
    const y2 = corrAt(lag);
    const y3 = corrAt(lag + 1);
    const denom = y1 - 2 * y2 + y3;
    if (Math.abs(denom) < 1e-9) return lag;
    return lag + 0.5 * (y1 - y3) / denom;
  }

  getStableReading() {
    if (this.history.length < 4) return null;

    const latestNoteNumber = this.history[this.history.length - 1].note.midi;
    const sameNote = this.history.filter(r => Math.abs(r.note.midi - latestNoteNumber) <= 0);
    if (sameNote.length < 4) return null;

    const freqs = sameNote.map(r => r.frequency).sort((a, b) => a - b);
    const median = freqs[Math.floor(freqs.length / 2)];
    const spreadCents = this.frequencySpreadInCents(freqs[0], freqs[freqs.length - 1]);
    if (spreadCents > 8) return null;

    const confidence = sameNote.reduce((s, r) => s + r.clarity, 0) / sameNote.length;
    const note = this.frequencyToNote(median);
    return { frequency: median, note, confidence };
  }

  frequencySpreadInCents(low, high) {
    return Math.abs(1200 * Math.log2(high / low));
  }

  frequencyToNote(frequency) {
    const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const midiExact = 69 + 12 * Math.log2(frequency / 440);
    const midi = Math.round(midiExact);
    const cents = Math.round((midiExact - midi) * 100);
    const name = noteNames[((midi % 12) + 12) % 12];
    const octave = Math.floor(midi / 12) - 1;
    return { midi, name, octave, cents };
  }

  closestStandardString(noteName, octave) {
    const standard = [
      { id: 'E2', name: 'E', octave: 2 },
      { id: 'A2', name: 'A', octave: 2 },
      { id: 'D3', name: 'D', octave: 3 },
      { id: 'G3', name: 'G', octave: 3 },
      { id: 'B3', name: 'B', octave: 3 },
      { id: 'E4', name: 'E', octave: 4 }
    ];
    return standard.find(s => s.name === noteName && s.octave === octave)?.id || null;
  }
}

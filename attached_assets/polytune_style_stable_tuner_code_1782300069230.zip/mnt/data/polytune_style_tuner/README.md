# Stable Guitar Tuner Engine

A browser-based single-string guitar tuner demo inspired by premium tuner behaviour.

## Features

- Web Audio microphone input
- Attack rejection so the pick transient does not make the needle jump
- Autocorrelation pitch detection
- Confidence thresholding
- Short-term median stabilisation
- Outlier rejection using cents spread
- ±2 cent centre lock / hysteresis zone
- Smoothed display needle
- Standard guitar string visual mapping

## Run

Open `index.html` from a local web server. Browser microphone access usually requires HTTPS or localhost.

Example:

```bash
python3 -m http.server 8080
```

Then visit:

```text
http://localhost:8080
```

## Main engine file

`tuner-engine.js`

Important settings:

```js
new StableGuitarTuner({
  minFrequency: 60,
  maxFrequency: 1400,
  attackRejectMs: 90,
  analysisWindowMs: 260,
  minRms: 0.008,
  minClarity: 0.72,
  centerLockCents: 2,
  displaySmoothing: 0.22
});
```

## Developer notes

For a production Fretboard Universe tuner, the next step is to add:

1. Separate tuning preset data: Standard, Drop D, Eb, D Standard, Open G, etc.
2. Polyphonic mode using frequency-domain analysis.
3. Real string-range energy detection for instant string vibration animation.
4. Calibration support: 440 Hz, 432 Hz and custom A4.
5. More robust low-frequency detection for bass and 8-string guitars.
